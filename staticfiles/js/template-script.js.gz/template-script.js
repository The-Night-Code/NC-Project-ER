


function openSideNav() {
    document.getElementById("mySidenav").style.width = "250px";
    document.getElementById("mySidenav").style.width = "250px";
}
  
function closeSideNav() {
    document.getElementById("mySidenav").style.width = "0";
    document.getElementById("mySidenav").style.width = "0";
}
